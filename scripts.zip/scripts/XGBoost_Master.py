import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.ensemble import RandomForestRegressor
import shap
import matplotlib.pyplot as plt
import os
import datetime
from sklearn.model_selection import GroupKFold, train_test_split, RandomizedSearchCV
from sklearn.metrics import r2_score, mean_absolute_error
import warnings

warnings.filterwarnings('ignore')
plt.style.use('seaborn-v0_8-darkgrid')

class MasterIntegratedGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("XGBoost/RF Master Analysis (Max R-Squared & Plot Exports)")
        self.root.geometry("1200x900")
        
        self.best_model = None
        self.features = []
        self.target = 'InSAR_Normalized'
        self.df_annual = None
        self.train_split_df = None
        self.test_split_df = None
        self.df_annual_with_shap = None
        
        self.algo_choice = tk.StringVar(value="XGBoost")
        self.split_mode = tk.StringVar(value="Group 5-Fold CV (Strict Station Split)")
        self.impute_mode = tk.StringVar(value="Linear Interpolation")
        self.drop_stations_var = tk.StringVar(value="") 
        
        self.build_ui()

    def build_ui(self):
        f_top = ttk.LabelFrame(self.root, text=" 1. Data Load & Missing Value Handling ", padding=10)
        f_top.pack(fill="x", padx=10, pady=5)
        
        ttk.Button(f_top, text="Load Extracted CSV", command=self.load_data).grid(row=0, column=0, padx=5)
        self.lbl_info = ttk.Label(f_top, text="No data loaded", foreground="gray")
        self.lbl_info.grid(row=0, column=1, padx=5)
        
        ttk.Label(f_top, text="Imputation:").grid(row=0, column=2, padx=5)
        ttk.Combobox(f_top, textvariable=self.impute_mode, values=["Linear Interpolation", "Median Fill"], state="readonly", width=20).grid(row=0, column=3)
        
        ttk.Label(f_top, text="Drop Stations (Comma sep):").grid(row=0, column=4, padx=5)
        ttk.Entry(f_top, textvariable=self.drop_stations_var, width=15).grid(row=0, column=5)

        f_config = ttk.LabelFrame(self.root, text=" 2. Algorithm & Validation Strategy ", padding=10)
        f_config.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(f_config, text="Algorithm:").grid(row=0, column=0, padx=5)
        ttk.Combobox(f_config, textvariable=self.algo_choice, values=["XGBoost", "Random Forest"], state="readonly", width=15).grid(row=0, column=1)
        
        ttk.Label(f_config, text="Validation:").grid(row=0, column=2, padx=5)
        ttk.Combobox(f_config, textvariable=self.split_mode, values=["Group 5-Fold CV (Strict Station Split)", "Random Split (80/20)", "Temporal Split (Train <=2021, Test >=2022)"], state="readonly", width=40).grid(row=0, column=3)

        f_param = ttk.LabelFrame(self.root, text=" 3. Hyperparameters ", padding=10)
        f_param.pack(fill="x", padx=10, pady=5)
        
        params_default = {
            "n_estimators": "300", "learning_rate": "0.05", "max_depth": "6", 
            "subsample": "1.0", "colsample_bytree": "0.8", "min_child_weight": "2",
            "min_samples_split": "5", "min_samples_leaf": "2"
        }
        self.entries = {}
        for i, (key, val) in enumerate(params_default.items()):
            row = i // 4
            col = (i % 4) * 2
            ttk.Label(f_param, text=key + ":").grid(row=row, column=col, padx=5, pady=2, sticky='e')
            e = ttk.Entry(f_param, width=8)
            e.insert(0, val)
            e.grid(row=row, column=col+1, padx=5, pady=2, sticky='w')
            self.entries[key] = e

        f_main = ttk.LabelFrame(self.root, text=" 4. Execution & Logs ", padding=10)
        f_main.pack(fill="both", expand=True, padx=10, pady=5)
        
        btn_f1 = ttk.Frame(f_main)
        btn_f1.pack(fill="x", pady=2)
        ttk.Button(btn_f1, text="[1] AUTO-TUNE (Max R-Squared)", command=self.run_auto_tune).pack(side="left", padx=5)
        ttk.Button(btn_f1, text="[2] RUN TRAINING", command=self.run_train).pack(side="left", padx=5)
        ttk.Button(btn_f1, text="CLEAR LOG", command=self.clear_log).pack(side="right", padx=5)
        ttk.Button(btn_f1, text="COPY LOG", command=self.copy_log).pack(side="right", padx=5)

        self.txt_log = tk.Text(f_main, height=12, bg="#ffffff", font=("Consolas", 10))
        self.txt_log.pack(fill="both", expand=True, pady=5)

        f_export = ttk.LabelFrame(self.root, text=" 5. Artifacts Export ", padding=10)
        f_export.pack(fill="x", padx=10, pady=5)
        ttk.Button(f_export, text="Export Data & Splits (CSV)", command=self.export_all_data).pack(side="left", padx=5)
        ttk.Button(f_export, text="Export Station Trend Plots (Folder)", command=self.export_station_plots).pack(side="left", padx=5)

    def print_log(self, msg):
        self.txt_log.insert(tk.END, f"{msg}\n")
        self.txt_log.see(tk.END)
        self.root.update()

    def clear_log(self):
        self.txt_log.delete(1.0, tk.END)
        self.root.update()

    def copy_log(self):
        try:
            content = self.txt_log.get(1.0, tk.END).strip()
            if content:
                self.root.clipboard_clear()
                self.root.clipboard_append(content)
                self.root.update()
                self.txt_log.tag_add("sel", "1.0", "end")
                self.txt_log.focus_set()
                messagebox.showinfo("Success", "Log copied to clipboard!")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def get_run_suffix(self):
        algo = "XG" if self.algo_choice.get() == "XGBoost" else "RF"
        if "Group" in self.split_mode.get(): mode = "Group"
        elif "Random" in self.split_mode.get(): mode = "Random"
        else: mode = "Tem"
        return f"{algo}_{mode}"

    def load_data(self):
        path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not path: return
        try:
            self.df_raw = pd.read_csv(path)
            self.print_log(f"[SYSTEM] Loaded {len(self.df_raw)} rows from {os.path.basename(path)}")
            if 'InSAR_Normalized' in self.df_raw.columns:
                self.target = 'InSAR_Normalized'
            else:
                self.target = 'InSAR_Cumulative'
            self.lbl_info.config(text=f"Loaded: {len(self.df_raw)} rows", foreground="green")
        except Exception as e:
            self.print_log(f"[ERROR] {e}")

    def prepare_data(self):
        df = self.df_raw.copy()
        
        drop_list = [s.strip() for s in self.drop_stations_var.get().split(',') if s.strip()]
        if drop_list:
            df = df[~df['Station_ID'].astype(str).isin(drop_list)]
            self.print_log(f"Dropped stations: {drop_list}")

        self.features = [c for c in df.columns if c not in ['Station_ID', 'Lat', 'Lon', 'Year', 'InSAR_Cumulative', 'InSAR_Normalized', 'Unique_Pixel_ID', 'Join_ID']]
        
        self.print_log("--- MATH LOG: DATA PREPARATION ---")
        if self.impute_mode.get() == "Linear Interpolation":
            for feat in self.features:
                if 'Drop' in feat or 'Lag' in feat or 'Delta' in feat:
                    df[feat] = df.groupby('Station_ID')[feat].transform(lambda group: group.interpolate(method='linear', limit_direction='both'))
                else:
                    df[feat] = df[feat].interpolate(method='linear', limit_direction='both')
            df[self.features] = df[self.features].fillna(df[self.features].median())
            self.print_log("1. Linear Interpolation applied.")
        else:
            df[self.features] = df[self.features].fillna(df[self.features].median())
            self.print_log("1. Median Fill applied.")

        df = df.dropna(subset=[self.target]).reset_index(drop=True)
        self.df_annual = df
        return df

    def get_model_params(self):
        params = {k: v.get() for k, v in self.entries.items()}
        algo = self.algo_choice.get()
        if algo == "XGBoost":
            depth = params['max_depth']
            return xgb.XGBRegressor(
                n_estimators=int(params['n_estimators']),
                learning_rate=float(params['learning_rate']),
                max_depth=int(depth) if str(depth).lower() != 'none' else None,
                subsample=float(params['subsample']),
                colsample_bytree=float(params['colsample_bytree']),
                min_child_weight=float(params['min_child_weight']),
                random_state=42
            )
        else:
            depth = params['max_depth']
            return RandomForestRegressor(
                n_estimators=int(params['n_estimators']),
                max_depth=int(depth) if str(depth).lower() != 'none' else None,
                min_samples_split=int(params['min_samples_split']),
                min_samples_leaf=int(params['min_samples_leaf']),
                random_state=42
            )

    def run_auto_tune(self):
        if not hasattr(self, 'df_raw'):
            messagebox.showwarning("Warning", "Load data first.")
            return
        self.print_log("[SYSTEM] Starting Auto-Tune (Target: Maximize R2)...")
        self.root.update()
        try:
            df = self.prepare_data()
            X = df[self.features]
            y = df[self.target]
            algo = self.algo_choice.get()
            
            if algo == "XGBoost":
                param_dist = {
                    'n_estimators': [100, 200, 300],
                    'learning_rate': [0.05, 0.1, 0.15],
                    'max_depth': [4, 6, 8],
                    'subsample': [0.8, 1.0],
                    'colsample_bytree': [0.8, 1.0]
                }
                base_model = xgb.XGBRegressor(random_state=42)
            else:
                param_dist = {
                    'n_estimators': [100, 200, 300],
                    'max_depth': [5, 10, None],
                    'min_samples_split': [2, 5],
                    'min_samples_leaf': [1, 2]
                }
                base_model = RandomForestRegressor(random_state=42)
                
            search = RandomizedSearchCV(base_model, param_dist, n_iter=20, cv=3, scoring='r2', n_jobs=-1, random_state=42)
            search.fit(X, y)
            best_p = search.best_params_
            self.print_log(f"[SUCCESS] Best Params: {best_p}\n")
            
            for k, v in best_p.items():
                if k in self.entries:
                    self.entries[k].delete(0, tk.END)
                    self.entries[k].insert(0, str(v))
        except Exception as e:
            self.print_log(f"[ERROR] {e}")

    def calculate_and_export_detailed_shap(self, X, full_df):
        self.print_log("[SYSTEM] Calculating Detailed SHAP impacts...")
        
        if self.algo_choice.get() == "Random Forest":
            explainer = shap.TreeExplainer(self.best_model)
            shap_values = explainer.shap_values(X)
        else:
            explainer = shap.Explainer(self.best_model)
            shap_values = explainer(X).values
            
        mean_abs_shap = np.abs(shap_values).mean(axis=0)
        total_impact = np.sum(mean_abs_shap) if np.sum(mean_abs_shap) > 0 else 1
        pct = (mean_abs_shap / total_impact) * 100
        
        suffix = self.get_run_suffix()
        
        # 1. Export Summary Chart (.png)
        colors = plt.cm.Paired(np.linspace(0, 1, len(self.features)))
        plt.figure(figsize=(10, 7))
        wedges, texts, autotexts = plt.pie(pct, autopct='%1.1f%%', startangle=140, colors=colors, wedgeprops=dict(width=0.4, edgecolor='w'))
        plt.legend(wedges, self.features, title="Features", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
        plt.title(f"Detailed SHAP Impact [{suffix}]")
        plt.tight_layout()
        plt.savefig(f"SHAP_Detailed_{suffix}.png", dpi=300)
        plt.close()
        
        # 2. Export Summary Table (.csv)
        shap_summary_df = pd.DataFrame({
            'Feature': self.features,
            'Mean_Abs_SHAP': mean_abs_shap,
            'Impact_Percentage': pct
        }).sort_values(by='Impact_Percentage', ascending=False)
        csv_name = f"SHAP_Summary_{suffix}.csv"
        shap_summary_df.to_csv(csv_name, index=False)
        self.print_log(f"[SUCCESS] Saved SHAP Summary CSV: {csv_name}")

        # 3. Sub-factor percentage calculation (Row-level)
        row_totals = np.abs(shap_values).sum(axis=1)
        row_totals[row_totals == 0] = 1 
        
        gw_factors = [f for f in self.features if 'GW' in f or 'Drop' in f or 'Lag' in f]
        gw_idx = [i for i, f in enumerate(self.features) if f in gw_factors]
        other_idx = [i for i, f in enumerate(self.features) if f not in gw_factors]
        
        gw_impact_sum = np.abs(shap_values[:, gw_idx]).sum(axis=1)
        other_impact_sum = np.abs(shap_values[:, other_idx]).sum(axis=1)
        
        full_df['SHAP_GW_Impact_%'] = np.round((gw_impact_sum / row_totals) * 100, 2)
        full_df['SHAP_Other_Impact_%'] = np.round((other_impact_sum / row_totals) * 100, 2)
        
        for i, feat in enumerate(self.features):
            full_df[f'SHAP_{feat}_%'] = np.round((np.abs(shap_values[:, i]) / row_totals) * 100, 2)

        self.df_annual_with_shap = full_df

    def analyze_anomalies(self, test_df):
        test_df['Abs_Error'] = np.abs(test_df[self.target] - test_df['Predicted'])
        best_row = test_df.loc[test_df['Abs_Error'].idxmin()]
        worst_row = test_df.loc[test_df['Abs_Error'].idxmax()]
        
        self.print_log("\n--- ANOMALY ANALYSIS ---")
        self.print_log(f"BEST Station: {best_row['Station_ID']} (MAE {best_row['Abs_Error']:.2f})")
        self.print_log(f"WORST Station: {worst_row['Station_ID']} (MAE {worst_row['Abs_Error']:.2f}) -> Problem Year: {worst_row['Year']}")

    def run_train(self):
        if not hasattr(self, 'df_raw'):
            messagebox.showwarning("Warning", "Load data first.")
            return
            
        df = self.prepare_data()
        X = df[self.features]
        y = df[self.target]
        groups = df['Station_ID']
        
        algo = self.algo_choice.get()
        mode = self.split_mode.get()
        self.print_log(f"\n--- MODEL TRAINING ({algo}) ---")
        
        if "Group" in mode:
            self.print_log("Validation: Group K-Fold (Strict Station).")
            gkf = GroupKFold(n_splits=5)
            r2_list, mae_list, models, splits = [], [], [], []
            
            for fold, (train_idx, test_idx) in enumerate(gkf.split(X, y, groups=groups)):
                X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
                y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
                
                model = self.get_model_params()
                model.fit(X_train, y_train)
                preds = model.predict(X_test)
                
                r2 = r2_score(y_test, preds)
                mae = mean_absolute_error(y_test, preds)
                
                r2_list.append(r2)
                mae_list.append(mae)
                models.append(model)
                splits.append((train_idx, test_idx))
                
            best_idx = int(np.argmax(r2_list))
            self.best_model = models[best_idx]
            b_train, b_test = splits[best_idx]
            
            self.train_split_df = df.iloc[b_train].copy()
            self.test_split_df = df.iloc[b_test].copy()
            self.test_split_df['Predicted'] = self.best_model.predict(X.iloc[b_test])
            
            self.print_log(f"Avg R-Squared: {np.mean(r2_list):.4f} | Avg MAE: {np.mean(mae_list):.2f} mm")
            
        elif "Random" in mode:
            self.print_log("Validation: Random Split (80/20).")
            train_idx, test_idx = train_test_split(np.arange(len(df)), test_size=0.2, random_state=42)
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
            
            self.best_model = self.get_model_params()
            self.best_model.fit(X_train, y_train)
            preds = self.best_model.predict(X_test)
            
            self.print_log(f"R-Squared: {r2_score(y_test, preds):.4f} | MAE: {mean_absolute_error(y_test, preds):.2f} mm")
            
            self.train_split_df = df.iloc[train_idx].copy()
            self.test_split_df = df.iloc[test_idx].copy()
            self.test_split_df['Predicted'] = preds

        else: # Temporal
            self.print_log("Validation: Temporal Split (Train <=2021, Test >=2022).")
            train_idx = df[df['Year'] <= 2021].index
            test_idx = df[df['Year'] >= 2022].index
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
            
            self.best_model = self.get_model_params()
            self.best_model.fit(X_train, y_train)
            preds = self.best_model.predict(X_test)
            
            self.print_log(f"R-Squared: {r2_score(y_test, preds):.4f} | MAE: {mean_absolute_error(y_test, preds):.2f} mm")
            
            self.train_split_df = df.iloc[train_idx].copy()
            self.test_split_df = df.iloc[test_idx].copy()
            self.test_split_df['Predicted'] = preds

        df['Predicted_Subsidence'] = self.best_model.predict(X)
        self.calculate_and_export_detailed_shap(X, df)
        self.analyze_anomalies(self.test_split_df)

    def export_all_data(self):
        if self.df_annual_with_shap is None:
            messagebox.showwarning("Warning", "Run training first.")
            return
            
        suffix = self.get_run_suffix()
        max_yr = self.df_annual_with_shap['Year'].max()
        hotspot_df = self.df_annual_with_shap[self.df_annual_with_shap['Year'] == max_yr].copy()
        
        export_cols = ['Station_ID', 'Lat', 'Lon', 'Year', 'InSAR_Normalized', 'Predicted_Subsidence', 'SHAP_GW_Impact_%', 'SHAP_Other_Impact_%']
        shap_sub_cols = [c for c in hotspot_df.columns if c.startswith('SHAP_') and c.endswith('_%')]
        for c in shap_sub_cols:
            if c not in export_cols:
                export_cols.append(c)
        export_cols.extend(self.features)
        
        avail_cols = [c for c in export_cols if c in hotspot_df.columns]
        
        out_name = f"Hotspot_Data_{max_yr}_{suffix}.csv"
        hotspot_df[avail_cols].to_csv(out_name, index=False)
        self.print_log(f"[SUCCESS] Exported Map Data: {out_name}")
        
        self.train_split_df.to_csv(f"Exported_Train_Split_{suffix}.csv", index=False)
        self.test_split_df.to_csv(f"Exported_Test_Split_{suffix}.csv", index=False)
        
        messagebox.showinfo("Success", "Exported Hotspot Data and Train/Test Splits successfully.")

    def export_station_plots(self):
        if self.test_split_df is None:
            messagebox.showwarning("Warning", "Run training first.")
            return
            
        suffix = self.get_run_suffix()
        folder_name = f"Station_Plots_{suffix}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}"
        os.makedirs(folder_name, exist_ok=True)
        
        # วาดกราฟของทุกสถานีที่ถูกนำมา Test
        stations = self.test_split_df['Station_ID'].unique()
        for st_id in stations:
            plt.figure(figsize=(8, 5))
            
            # ข้อมูลจริงทั้งหมดของสถานีนี้
            st_data = self.df_annual_with_shap[self.df_annual_with_shap['Station_ID'] == st_id].sort_values('Year')
            plt.plot(st_data['Year'], st_data[self.target], 'b-o', label='Actual InSAR', linewidth=2)
            
            # ข้อมูลทำนาย
            if 'Predicted_Subsidence' in st_data.columns:
                plt.plot(st_data['Year'], st_data['Predicted_Subsidence'], 'r--s', label=f'Predicted ({self.algo_choice.get()})', linewidth=2)
            
            clay_col = 'Clay_Thick' if 'Clay_Thick' in st_data.columns else 'Clay thickness (m)'
            clay_val = st_data[clay_col].iloc[0] if clay_col in st_data.columns else "N/A"
            
            plt.title(f"Station: {st_id} | Clay: {clay_val} m", fontsize=12, fontweight='bold')
            plt.xlabel("Year", fontweight='bold')
            plt.ylabel("Subsidence (mm)", fontweight='bold')
            plt.xticks(st_data['Year'].astype(int))
            plt.legend()
            plt.grid(True, linestyle='--', alpha=0.6)
            plt.tight_layout()
            
            file_path = os.path.join(folder_name, f"Station_{st_id}.png")
            plt.savefig(file_path, dpi=300)
            plt.close()
            
        self.print_log(f"[SUCCESS] Exported {len(stations)} trend plots to folder: {folder_name}")
        messagebox.showinfo("Success", f"Exported {len(stations)} station plots to folder:\n{folder_name}")

if __name__ == "__main__":
    root = tk.Tk()
    app = MasterIntegratedGUI(root)
    root.mainloop()