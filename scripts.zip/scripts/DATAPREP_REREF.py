import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
import numpy as np
import h5py
import os
import threading
import glob
import datetime

try:
    import rasterio
    from pyproj import Transformer
except ImportError:
    rasterio = None
    Transformer = None

class UnifiedDataPrepGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Step 2: Advanced Data Prep (5-Year Lag & Auto-Filtering)")
        self.root.geometry("850x800")
        
        self.csv_path = tk.StringVar()
        self.h5_path = tk.StringVar()
        self.par_path = tk.StringVar()
        self.ndbi_folder = tk.StringVar()
        self.extraction_mode = tk.StringVar(value="Point (1 Pixel)")
        
        self.convert_vertical = tk.BooleanVar(value=True)
        self.incidence_angle = tk.DoubleVar(value=33.93)
        
        # Reference Variables
        self.ref_rate = tk.DoubleVar(value=-3.38) # Default CUSV Rate
        self.ref_x1 = tk.IntVar(value=894) # Default BMA Narrow/Wide
        self.ref_x2 = tk.IntVar(value=931)
        self.ref_y1 = tk.IntVar(value=979)
        self.ref_y2 = tk.IntVar(value=1000)
        
        self.build_ui()

    def build_ui(self):
        # 1. Inputs
        f_in = ttk.LabelFrame(self.root, text=" 1. Required Inputs ", padding=10)
        f_in.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(f_in, text="CSV (DATA_CUM_FILLED):").grid(row=0, column=0, sticky="w", pady=5)
        ttk.Entry(f_in, textvariable=self.csv_path, width=45).grid(row=0, column=1, padx=5)
        ttk.Button(f_in, text="Browse", command=lambda: self.browse_file(self.csv_path, "CSV", "*.csv")).grid(row=0, column=2)

        ttk.Label(f_in, text="H5 File (cum_filt.h5):").grid(row=1, column=0, sticky="w", pady=5)
        ttk.Entry(f_in, textvariable=self.h5_path, width=45).grid(row=1, column=1, padx=5)
        ttk.Button(f_in, text="Browse", command=lambda: self.browse_file(self.h5_path, "H5", "*.h5")).grid(row=1, column=2)

        ttk.Label(f_in, text="DEM Parameter (EQA.dem_par):").grid(row=2, column=0, sticky="w", pady=5)
        ttk.Entry(f_in, textvariable=self.par_path, width=45).grid(row=2, column=1, padx=5)
        ttk.Button(f_in, text="Browse", command=lambda: self.browse_file(self.par_path, "PAR", "*.*")).grid(row=2, column=2)

        # 2. Options
        f_opt = ttk.LabelFrame(self.root, text=" 2. Spatial Options ", padding=10)
        f_opt.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(f_opt, text="Extraction Mode:").grid(row=0, column=0, sticky="w")
        ttk.Combobox(f_opt, textvariable=self.extraction_mode, values=["Point (1 Pixel)", "3x3 Average (Avoid Spatial Leakage)"], state="readonly", width=35).grid(row=0, column=1, sticky="w", padx=5)
        
        ttk.Label(f_opt, text="NDBI Folder (Optional):").grid(row=1, column=0, sticky="w", pady=10)
        ttk.Entry(f_opt, textvariable=self.ndbi_folder, width=45).grid(row=1, column=1, padx=5)
        ttk.Button(f_opt, text="Browse", command=lambda: self.ndbi_folder.set(filedialog.askdirectory())).grid(row=1, column=2)

        # 3. Geometric & Reference
        f_ref = ttk.LabelFrame(self.root, text=" 3. Geometric & Reference Point Calibration ", padding=10)
        f_ref.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(f_ref, text="Incidence Angle (degrees):").grid(row=0, column=0, sticky="w")
        ttk.Entry(f_ref, textvariable=self.incidence_angle, width=10).grid(row=0, column=1, sticky="w", padx=5)
        
        ttk.Label(f_ref, text="GNSS Ref Rate (mm/yr):").grid(row=0, column=2, sticky="e", padx=10)
        ttk.Entry(f_ref, textvariable=self.ref_rate, width=10).grid(row=0, column=3, sticky="w", padx=5)
        
        ttk.Label(f_ref, text="Ref X (Start-End):").grid(row=1, column=0, sticky="w", pady=5)
        x_frame = ttk.Frame(f_ref)
        x_frame.grid(row=1, column=1, sticky="w")
        ttk.Entry(x_frame, textvariable=self.ref_x1, width=6).pack(side="left")
        ttk.Label(x_frame, text="-").pack(side="left")
        ttk.Entry(x_frame, textvariable=self.ref_x2, width=6).pack(side="left")
        
        ttk.Label(f_ref, text="Ref Y (Start-End):").grid(row=1, column=2, sticky="e", padx=10)
        y_frame = ttk.Frame(f_ref)
        y_frame.grid(row=1, column=3, sticky="w")
        ttk.Entry(y_frame, textvariable=self.ref_y1, width=6).pack(side="left")
        ttk.Label(y_frame, text="-").pack(side="left")
        ttk.Entry(y_frame, textvariable=self.ref_y2, width=6).pack(side="left")

        # 4. Action
        f_run = ttk.Frame(self.root, padding=10)
        f_run.pack(fill="x", padx=10, pady=10)
        
        self.btn_run = ttk.Button(f_run, text="EXTRACT DATA & GENERATE 5-YEAR LAGS", command=self.start_process)
        self.btn_run.pack(pady=10)
        
        self.lbl_status = ttk.Label(self.root, text="Ready", font=("Arial", 10, "bold"), foreground="blue")
        self.lbl_status.pack(pady=5)

    def browse_file(self, var, f_type, ext):
        f = filedialog.askopenfilename(filetypes=[(f"{f_type} files", ext), ("All files", "*.*")])
        if f: var.set(f)

    def read_dem_par(self, filepath):
        params = {}
        with open(filepath, 'r') as f:
            for line in f:
                parts = line.replace(':', ' ').strip().split()
                if len(parts) >= 2:
                    try: params[parts[0].strip().lower()] = float(parts[1])
                    except ValueError: pass
        return params

    def start_process(self):
        if not all([self.csv_path.get(), self.h5_path.get(), self.par_path.get()]):
            messagebox.showwarning("Warning", "Please select CSV, H5, and PAR files.")
            return
        
        self.btn_run.config(state="disabled")
        threading.Thread(target=self.process_data, daemon=True).start()

    def process_data(self):
        try:
            self.lbl_status.config(text="Processing H5 Data & Calibrating Reference...", foreground="orange")
            df_well = pd.read_csv(self.csv_path.get())
            
            name_map = {
                'GW_Level (m below ground)': 'GW_Level', 
                'Clay thickness (m)': 'Clay_Thick',
                'Lat': 'Lat', 'Lon': 'Lon', 'พิกัด lat': 'Lat', 'พิกัด long': 'Lon'
            }
            df_well.rename(columns=name_map, inplace=True)
            
            # --- AUTO STATION EXCLUSION (Missing GW in 2024) ---
            self.lbl_status.config(text="Analyzing Station Continuity...")
            max_year_data = df_well['Year'].max()
            missing_latest_gw = df_well[(df_well['Year'] == max_year_data) & (df_well['GW_Level'].isna())]['Station_ID'].unique()
            missing_latest_gw = [str(x) for x in missing_latest_gw]
            
            # Export Exclusion Report
            exclusion_report = pd.DataFrame({
                'Station_ID': df_well['Station_ID'].unique()
            })
            exclusion_report['Status'] = np.where(exclusion_report['Station_ID'].astype(str).isin(missing_latest_gw), 'Dropped (Missing 2024)', 'Retained')
            exclusion_report.to_csv("Station_Exclusion_Report.csv", index=False)
            
            # Drop the stations
            if len(missing_latest_gw) > 0:
                print(f"[SYSTEM] Dropping {len(missing_latest_gw)} stations with missing latest data: {missing_latest_gw}")
                df_well = df_well[~df_well['Station_ID'].astype(str).isin(missing_latest_gw)].copy()
            
            # Linear Interpolate remaining data for continuity BEFORE lag generation
            df_well['GW_Level'] = df_well.groupby('Station_ID')['GW_Level'].transform(lambda x: x.interpolate(method='linear', limit_direction='both'))
            
            par = self.read_dem_par(self.par_path.get())
            c_lon, c_lat = par['corner_lon'], par['corner_lat']
            p_lon, p_lat = par['post_lon'], par['post_lat']
            
            extracted_data = []
            
            with h5py.File(self.h5_path.get(), 'r') as f:
                dates_str = [d.decode('utf-8') if hasattr(d, 'decode') else str(d) for d in f['imdates'][:]]
                years = [int(d[:4]) for d in dates_str]
                
                dt_dates = [datetime.datetime.strptime(d, '%Y%m%d') for d in dates_str]
                def get_dec_year(d):
                    start = datetime.datetime(d.year, 1, 1)
                    end = datetime.datetime(d.year + 1, 1, 1)
                    return d.year + (d - start).total_seconds() / (end - start).total_seconds()
                dec_years = np.array([get_dec_year(d) for d in dt_dates])
                time_elapsed = dec_years - dec_years[0]
                
                cum_data = f['cum'][:]
                _, max_y, max_x = cum_data.shape
                
                x1, x2 = self.ref_x1.get(), self.ref_x2.get()
                y1, y2 = self.ref_y1.get(), self.ref_y2.get()
                ref_area = cum_data[:, y1:y2, x1:x2]
                ref_area_masked = np.where(ref_area == 0, np.nan, ref_area)
                ref_ts_los = np.nanmean(ref_area_masked, axis=(1, 2))
                ref_rate_val = self.ref_rate.get()
                
                cos_factor = np.cos(np.radians(self.incidence_angle.get())) if self.convert_vertical.get() else 1.0
                
                # Get unique station locations to avoid duplicating logic
                stations_loc = df_well[['Station_ID', 'Lon', 'Lat']].drop_duplicates()
                
                for _, row in stations_loc.iterrows():
                    st_id = row['Station_ID']
                    cx = int(round((float(row['Lon']) - c_lon) / p_lon))
                    cy = int(round((float(row['Lat']) - c_lat) / p_lat))
                    
                    if not (0 <= cx < max_x and 0 <= cy < max_y): continue
                    
                    if "3x3" in self.extraction_mode.get():
                        # Extract 3x3 window and take MEAN immediately to avoid pseudoreplication
                        window = cum_data[:, max(0, cy-1):min(max_y, cy+2), max(0, cx-1):min(max_x, cx+2)]
                        window_masked = np.where(window == 0, np.nan, window)
                        ts_raw = np.nanmean(window_masked, axis=(1, 2))
                    else:
                        ts_raw = cum_data[:, cy, cx]
                    
                    ts_rel = ts_raw - ref_ts_los
                    ts_vert = ts_rel / cos_factor
                    ts_abs = ts_vert + (ref_rate_val * time_elapsed)
                    
                    df_temp = pd.DataFrame({'Year': years, 'Cum_Value': ts_abs})
                    yearly_mean = df_temp.groupby('Year')['Cum_Value'].mean().to_dict()
                    
                    # Append back to df_well
                    st_mask = df_well['Station_ID'] == st_id
                    df_well.loc[st_mask, 'InSAR_Cumulative'] = df_well.loc[st_mask, 'Year'].map(yearly_mean)

            self.lbl_status.config(text="Calculating 5-Year Deep Lags & Physics Variables...")
            df_out = df_well.copy()
            df_out = df_out.sort_values(['Station_ID', 'Year']).reset_index(drop=True)
            
            # --- FEATURE ENGINEERING (5-YEAR LAGS) ---
            base_ins = df_out.groupby('Station_ID')['InSAR_Cumulative'].transform('first')
            df_out['InSAR_Normalized'] = df_out['InSAR_Cumulative'] - base_ins
            
            base_gw = df_out.groupby('Station_ID')['GW_Level'].transform('first')
            df_out['Cum_GW_Drop'] = df_out['GW_Level'] - base_gw
            
            df_out['Delta_GW'] = df_out.groupby('Station_ID')['GW_Level'].diff().fillna(0)
            
            # Generate 5-year lags for both Drop (Delta) and Absolute GW Level
            for i in range(1, 6):
                df_out[f'GW_Drop_Lag{i}'] = df_out.groupby('Station_ID')['Delta_GW'].shift(i).fillna(0)
                df_out[f'GW_Level_Lag{i}'] = df_out.groupby('Station_ID')['GW_Level'].shift(i).fillna(method='bfill')

            # NDBI Processing
            ndbi_dir = self.ndbi_folder.get()
            if ndbi_dir and rasterio is not None:
                self.lbl_status.config(text="Extracting NDBI (Spatial Join)...")
                df_out['NDBI_Value'] = np.nan
                transformers = {}
                
                for idx, row in df_out.iterrows():
                    year, lon, lat = int(row['Year']), row['Lon'], row['Lat']
                    tif_files = glob.glob(os.path.join(ndbi_dir, f"*{year}*.tif"))
                    if tif_files:
                        try:
                            with rasterio.open(tif_files[0]) as src:
                                if src.crs and src.crs.to_epsg() != 4326:
                                    crs_key = src.crs.to_string()
                                    if crs_key not in transformers: transformers[crs_key] = Transformer.from_crs("EPSG:4326", src.crs, always_xy=True)
                                    px, py = transformers[crs_key].transform(lon, lat)
                                else:
                                    px, py = lon, lat
                                val = list(src.sample([(px, py)]))[0][0]
                                if val != src.nodata: df_out.at[idx, 'NDBI_Value'] = float(val)
                        except Exception: pass

            self.lbl_status.config(text="Finalizing Dataset...")
            
            # Save raw extracted for formula checking
            df_out.to_csv("XGBoost_Ready_Master_FormulaCheck.csv", index=False)
            
            # Filter for ML (Exclude the base year 2014 as it's just 0s)
            min_year = df_out.groupby('Station_ID')['Year'].transform('min')
            df_ml = df_out[df_out['Year'] > min_year].copy()
            
            # Final median fill for any edge cases
            num_cols = df_ml.select_dtypes(include=[np.number]).columns
            df_ml[num_cols] = df_ml[num_cols].fillna(df_ml[num_cols].median())

            # Define exact required columns for ML Master
            req_cols = ['Station_ID', 'Lat', 'Lon', 'Year', 'GW_Level', 'Clay_Thick', 
                        'Cum_GW_Drop', 'Delta_GW', 'InSAR_Cumulative', 'InSAR_Normalized']
            lag_cols = [f'GW_Drop_Lag{i}' for i in range(1,6)] + [f'GW_Level_Lag{i}' for i in range(1,6)]
            req_cols.extend(lag_cols)
            if 'NDBI_Value' in df_ml.columns: req_cols.append('NDBI_Value')
            
            df_ml = df_ml[[c for c in req_cols if c in df_ml.columns]]

            output_file = "XGBoost_Ready_Master.csv"
            df_ml.to_csv(output_file, index=False)
            
            dropped_count = len(missing_latest_gw)
            msg = f"Data Prep Complete!\n\nDropped Stations: {dropped_count} (Saved in Station_Exclusion_Report.csv)\nGenerated 5-Year Lag Features.\n\nML Ready Data: {output_file} ({len(df_ml)} rows)\n\nProceed to Step 3!"
            self.root.after(0, lambda: messagebox.showinfo("Success", msg))
            self.root.after(0, lambda: self.lbl_status.config(text="Status: Completed. Lags Generated.", foreground="green"))
            
        except Exception as e:
            self.root.after(0, lambda e=e: messagebox.showerror("Error", str(e)))
        finally:
            self.root.after(0, lambda: self.btn_run.config(state="normal"))

if __name__ == "__main__":
    root = tk.Tk()
    app = UnifiedDataPrepGUI(root)
    root.mainloop()