import pandas as pd
import folium
from folium.plugins import HeatMap, Fullscreen
import branca.colormap as cm
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import numpy as np
from datetime import datetime

DISTRICT_CODES = {
    "01": "Phra Nakhon", "02": "Dusit", "03": "Nong Chok", "04": "Bang Rak", "05": "Bang Khen",
    "06": "Bang Kapi", "07": "Pathum Wan", "08": "Pom Prap Sattru Phai", "09": "Phra Khanong", "10": "Min Buri",
    "11": "Lat Krabang", "12": "Yan Nawa", "13": "Samphanthawong", "14": "Phaya Thai", "15": "Thon Buri",
    "16": "Bangkok Yai", "17": "Huai Khwang", "18": "Khlong San", "19": "Taling Chan", "20": "Bangkok Noi",
    "21": "Bang Khun Thian", "22": "Phasi Charoen", "23": "Nong Khaem", "24": "Rat Burana", "25": "Bang Phlat",
    "26": "Din Daeng", "27": "Bueng Kum", "28": "Sathon", "29": "Bang Sue", "30": "Chatuchak",
    "31": "Bang Kho Laem", "32": "Prawet", "33": "Khlong Toei", "34": "Suan Luang", "35": "Chom Thong",
    "36": "Don Mueang", "37": "Ratchathewi", "38": "Lat Phrao", "39": "Watthana", "40": "Bang Khae",
    "41": "Lak Si", "42": "Sai Mai", "43": "Khan Na Yao", "44": "Saphan Sung", "45": "Wang Thonglang",
    "46": "Khlong Sam Wa", "47": "Bang Na", "48": "Thawi Watthana", "49": "Thung Khru", "50": "Bang Bon"
}

class ProfessionalComparativeMap:
    def __init__(self, root):
        self.root = root
        self.root.title("Bangkok Subsidence Policy Map - Ultimate Defense Edition")
        self.root.geometry("650x450")
        self.rf_path = tk.StringVar()
        self.xg_path = tk.StringVar()
        self.welldata_path = tk.StringVar()
        self.build_ui()

    def build_ui(self):
        f1 = ttk.LabelFrame(self.root, text=" 📂 Data Integration (RF + XGB + Well) ", padding=15)
        f1.pack(fill="x", padx=15, pady=10)
        
        inputs = [("1) Random Forest CSV:", self.rf_path), 
                  ("2) XGBoost CSV:", self.xg_path), 
                  ("3) Well Master Data:", self.welldata_path)]
        
        for i, (txt, var) in enumerate(inputs):
            ttk.Label(f1, text=txt).grid(row=i, column=0, sticky="w", pady=5)
            ttk.Entry(f1, textvariable=var, width=40).grid(row=i, column=1, padx=5)
            ttk.Button(f1, text="Browse", command=lambda v=var: v.set(filedialog.askopenfilename(filetypes=[("CSV", "*.csv")]))).grid(row=i, column=2)

        btn = tk.Button(self.root, text="🛡️ GENERATE OFFICIAL POLICY MAP", bg="#2980b9", fg="white", font=('Arial', 12, 'bold'), command=self.generate)
        btn.pack(pady=20, fill="x", padx=30)

    def safe_read_csv(self, file_path):
        try: return pd.read_csv(file_path)
        except UnicodeDecodeError: return pd.read_csv(file_path, encoding='cp874')

    def generate(self):
        if not all([self.rf_path.get(), self.xg_path.get(), self.welldata_path.get()]):
            messagebox.showwarning("Warning", "กรุณาระบุไฟล์ให้ครบทั้ง 3 ช่องครับ")
            return
        
        try:
            df_rf = self.safe_read_csv(self.rf_path.get())
            df_xg = self.safe_read_csv(self.xg_path.get())
            df_wd = self.safe_read_csv(self.welldata_path.get())

            rf_cols = {c: f"{c}_RF" for c in df_rf.columns if c.startswith('SHAP_') or c == 'Predicted_Subsidence'}
            xg_cols = {c: f"{c}_XG" for c in df_xg.columns if c.startswith('SHAP_') or c == 'Predicted_Subsidence'}
            df_rf.rename(columns=rf_cols, inplace=True); df_xg.rename(columns=xg_cols, inplace=True)
            df_merged = pd.merge(df_rf, df_xg[['Station_ID'] + list(xg_cols.values())], on='Station_ID', how='inner')
            
            df_merged['Join_ID'] = df_merged['Station_ID'].astype(str).str.split('.').str[0].str.lstrip('0')
            df_wd['Join_ID'] = df_wd['Station_ID'].astype(str).str.split('.').str[0].str.lstrip('0')
            df_merged = pd.merge(df_merged, df_wd[['Join_ID', 'Well_ID']], on='Join_ID', how='left')

            target_col = 'InSAR_Normalized' if 'InSAR_Normalized' in df_merged.columns else 'InSAR_Normalized (mm)'
            clay_col = 'Clay_Thick' if 'Clay_Thick' in df_merged.columns else 'Clay thickness (m)'
            
            if 'Predicted_Subsidence_RF' in df_merged.columns: df_merged['Error_RF'] = abs(df_merged[target_col] - df_merged['Predicted_Subsidence_RF'])
            if 'Predicted_Subsidence_XG' in df_merged.columns: df_merged['Error_XG'] = abs(df_merged[target_col] - df_merged['Predicted_Subsidence_XG'])

            min_err_rf, max_err_rf = df_merged['Error_RF'].min(), df_merged['Error_RF'].max()
            min_err_xg, max_err_xg = df_merged['Error_XG'].min(), df_merged['Error_XG'].max()

            m = folium.Map(location=[13.75, 100.51], zoom_start=11, tiles='CartoDB Positron')
            
            # --- 1. CSS Stylesheet (Responsive & Offsets) ---
            responsive_style = """
            <style>
                .custom-panel {
                    background: rgba(255,255,255,0.96); padding: 12px; border-radius: 8px; 
                    font-family: sans-serif; box-shadow: 3px 3px 10px rgba(0,0,0,0.2);
                }
                .manual-box { position: fixed; top: 10px; left: 50px; width: 480px; border: 2px solid #2980b9; max-height: 85vh; overflow-y: auto; z-index:9999; }
                .watermark-toggle { position: fixed; bottom: 20px; left: 20px; z-index:9999; }
                .watermark-title-mobile { display: none; }
                .watermark-info { width: 380px; left: 0; }
                
                .disclaimer-wrapper { position: fixed; bottom: 20px; right: 20px; z-index:9999; }
                .disclaimer-desktop { display: block; width: 280px; border: 1px solid #ccc; font-size: 10px; color:#555; }
                .disclaimer-mobile { display: none; }
                
                .station-label {
                    background: transparent !important; border: none !important; box-shadow: none !important;
                    font-weight: bold; color: #2c3e50; font-size: 11px;
                    text-shadow: 1px 1px 2px #fff, -1px -1px 2px #fff, 1px -1px 2px #fff, -1px 1px 2px #fff;
                }
                .mobile-legend { display: none; }
                .popup-container { width: 450px; font-family: sans-serif; color:#333; }
                .flex-row { display: flex; justify-content: space-between; gap: 10px; margin-bottom: 10px; }
                .flex-item { flex: 1; }

                @media (max-width: 768px) {
                    .manual-box { top: 10px; left: 10px; right: auto; width: 75vw; max-height: 45vh; font-size: 10px; }
                    .watermark-toggle { bottom: 20px; left: 10px; }
                    .watermark-title-desktop { display: none !important; }
                    .watermark-title-mobile { display: block !important; }
                    .watermark-info { width: 85vw; left: 0; bottom: 40px; }
                    
                    .disclaimer-desktop { display: none !important; }
                    .disclaimer-mobile { display: block !important; }
                    .disclaimer-wrapper { bottom: 20px; right: 10px; }
                    
                    .popup-container { width: 280px; }
                    .flex-row { flex-direction: column; gap: 5px; }
                    .legend { display: none !important; }
                    .mobile-legend { 
                        display: flex !important; flex-direction: column; align-items: center; justify-content: space-between;
                        position: fixed; right: 10px; top: 10px; height: 40vh; width: 35px; 
                        background: rgba(255,255,255,0.9); border-radius: 5px; border: 1px solid #ccc; z-index: 9999;
                        padding: 10px 0; box-shadow: 2px 2px 5px rgba(0,0,0,0.2); font-family: sans-serif; font-size: 9px; font-weight: bold; color: #333;
                    }
                }
            </style>
            """
            m.get_root().html.add_child(folium.Element(responsive_style))

            # --- 2. Color Legend (StepColormap) ---
            max_abs_val = df_merged[target_col].abs().max()
            upper_bound = max(max_abs_val, 150)
            colormap = cm.StepColormap(
                colors=['#2ecc71', '#f39c12', '#c0392b'],
                index=[0, 50, 100, upper_bound],
                vmin=0, vmax=upper_bound,
                caption="Absolute Cumulative Subsidence (mm) | Thresholds: 50, 100"
            )
            colormap.add_to(m)

            # --- 3. Vertical Color Legend (Mobile) ---
            mobile_legend_html = """
            <div class="mobile-legend">
                <span>>100</span>
                <div style="flex-grow: 1; width: 12px; margin: 5px 0; border-radius: 3px; background: linear-gradient(to bottom, #c0392b 0%, #c0392b 33.3%, #f39c12 33.3%, #f39c12 66.6%, #2ecc71 66.6%, #2ecc71 100%); border: 1px solid #7f8c8d;"></div>
                <span>0 mm</span>
            </div>
            """
            m.get_root().html.add_child(folium.Element(mobile_legend_html))

            # --- 4. Floating Manual (Update ทฤษฎีวิศวกรรมตามข้อมูลใหม่) ---
            help_html = f"""
            <div class="custom-panel manual-box">
                <details>
                    <summary style="font-weight:bold; cursor:pointer; color:#2980b9; font-size:14px;">📘 คู่มือ ทฤษฎี และการตีความ (Manual & Defense)</summary>
                    <div style="font-size:11px; margin-top:10px; line-height:1.6; color:#333;">
                        <b>1. คำนิยามตัวแปร:</b><br>
                        • <b>InSAR Subsidence:</b> ค่าการทรุดตัวสะสมจริง (Calibrated by CUSV GNSS)<br>
                        • <b>SHAP Value (%):</b> อิทธิพลที่แบบจำลองใช้อธิบายการทรุดตัว<br>
                        <hr>
                        <b>2. ข้อจำกัดโมเดล (Model Limitations):</b><br>
                        • <b>Concept Drift:</b> เนื่องจากพฤติกรรมการอัดตัวคายน้ำเปลี่ยนแปลงตามเวลา จึงต้อง Retrain โมเดลด้วยข้อมูลใหม่ทุก 3-5 ปี<br>
                        • <b>Omitted Variable Bias:</b> โมเดลขาดตัวแปรแฝง เช่น ปริมาณสูบน้ำเถื่อน และการมีค่า NDBI ติดลบ (พื้นที่เกษตร) อาจทำให้อ่านค่าน้ำหนักบรรทุกคลาดเคลื่อน<br>
                        <hr>
                        <b>3. ทฤษฎีวิศวกรรมและการแปลผล (Engineering Anomaly):</b><br>
                        • <b>ที่มาของข้อมูล:</b> ตัวเลขเฉลี่ยรายปีเป็นการคำนวณย้อนกลับจาก InSAR สะสม 10 ปี (2557-2567) ซึ่งสอดคล้องประจักษ์กับรายงานสถานการณ์น้ำบาดาล พ.ศ. 2565 (กรมทรัพยากรน้ำบาดาล)<br>
                          • <b>พื้นที่ชั้นใน:</b> ทรุดตัวชะลอลงที่ 0-10 มม./ปี (เทียบเท่าสะสม 0-100 มม.)<br>
                        • <b>Hotspot:</b> พบการทรุดตัวสะสมอย่างรุนแรงในรอบ 10 ปี (พ.ศ. 2557-2567) บริเวณชานเมืองและรอยต่อปริมณฑล โดยพบสูงสุดทื่ ฝั่งตะวันออก (เขตประเวศ) 177.5 มิลลิเมตร และ ฝั่งตะวันตกเฉียงใต้ (เขตบางขุนเทียน) 127 มิลลิเมตร <br>
                        • <b>กรณีศึกษา (สถานี 32001 ประเวศ):</b> ทรุดตัวจริงสูงถึง -177.5 มม. แต่โมเดลทายต่ำกว่าจริง เนื่องจากมีชั้นดินเหนียวอ่อน (Soft Clay) หนาถึง 40.83 ม. การวิเคราะห์ด้วย SHAP Value พบอิทธิพลจากตัวแปรหน่วงเวลาสูง (Lag 3-5) บ่งชี้ถึงการเกิดการอัดตัวแบบไม่ยืดหยุ่นถาวร (Inelastic Consolidation) ซึ่งเป็นผลพวงจากการสูบน้ำในอดีต (Delayed Compression) โครงสร้างดินจึงเสียหายถาวรไม่สามารถคืนตัวได้แม้ระดับความดันน้ำปัจจุบันจะฟื้นตัวแล้วก็ตาม<br>
                        <hr>
                        <b>4. เกณฑ์เตือนภัย (Thresholds):</b><br>
                        <span style="color:#d35400;">● <b>เฝ้าระวัง: > 50 mm</b></span> | <span style="color:#c0392b;">● <b>วิกฤต: > 100 mm</b></span><br>
                        (เสี่ยงต่อ Differential Settlement ของท่อประปา - <i>อ้างอิง: เฉลิมพล, 2567</i>)<br>
                        <hr>
                        <b>5. เอกสารอ้างอิงสำคัญ (Key References):</b><br>
                        <ul style='margin-top:2px; padding-left:15px; font-size:10px; line-height:1.4;'>
                            <li>Phien-wej, N., Giao, P.H., & Nutalaya, P. (2006). Land subsidence in Bangkok, Thailand. Engineering Geology, 82, 187-201.</li>
                            <li>Ahmed, S., et al. (2024). Monitoring land subsidence: the challenges of producing knowledge and groundwater management indicators in the Bangkok metropolitan region... Sustainability, 14.</li>
                            <li>Morishita, Y., et al. (2020). LiCSBAS: An Open-Source InSAR Time Series Analysis Package... Remote Sensing, 12(3).</li>
                            <li>เฉลิมพล ทับทิมทอง. (2567). การศึกษาปัญหาการเสียหายของท่อจ่ายน้ำประปาบริเวณส่วนโค้งล่างจากการทรุดตัวที่แตกต่างกัน. มจธ.</li>
                        </ul>
                        <hr>
                        <b>6. ความหมายของ Anomaly Tags (Best vs Worst):</b><br>
                        • 🌟 <b>Best Fit (Error < 5 มม.):</b> สถานีที่ทายแม่นยำที่สุด สะท้อนว่าตัวแปรที่ใช้ (น้ำบาดาล, ชั้นดิน) อธิบายพฤติกรรมพื้นที่นั้นได้ครบถ้วนในบริบทของการวิจัยครั้งนี้<br>
                        • 🚨 <b>Worst Anomaly (Error > 35 มม.):</b> สถานีที่ทายคลาดเคลื่อน ชี้ให้เห็นถึงอิทธิพลของ <i>Omitted Variable</i> ที่อยู่นอกเหนือสมการ<br>
                        • <b>ทำไม Best/Worst ของ RF และ XGB ถึงเป็นคนละสถานีกัน?:</b> <span style="color:#27ae60;"><b>Random Forest (Bagging)</b></span> หาค่าเฉลี่ยจากต้นไม้หลายต้น จึงทนทานต่อข้อมูลกวน (Noise) แต่ <span style="color:#8e44ad;"><b>XGBoost (Boosting)</b></span> เน้นสร้างต้นไม้แก้จุดที่ผิดพลาดในรอบก่อนหน้า จึงไวต่อรายละเอียดเชิงลึกแต่อาจ Overfit กับบางพื้นที่ การตอบสนองต่อภูมิประเทศและจุด Anomaly ของทั้งสองโมเดลจึงต่างกัน
                    </div>
                </details>
            </div>
            """
            m.get_root().html.add_child(folium.Element(help_html))

            # --- 5. Toggle Academic Watermark (ซ้ายล่าง) ---
            academic_watermark = """
            <div class="watermark-toggle">
                <div style="background: rgba(255,255,255,0.96); padding: 8px 15px; border-radius: 20px; border: 1px solid #bdc3c7; display: flex; align-items: center; gap: 10px; box-shadow: 2px 2px 5px rgba(0,0,0,0.1);">
                    <b class="watermark-title-desktop" style="color:#2c3e50; font-size:12px; margin:0;">🎓 แผนที่แนวโน้มการทรุดตัว (Subsidence Hotspot Map)</b>
                    <b class="watermark-title-mobile" style="color:#2c3e50; font-size:14px; margin:0;">🎓</b>
                    <button onclick="var el = document.getElementById('thesis-info'); el.style.display = (el.style.display === 'none') ? 'block' : 'none';" 
                            style="border-radius: 50%; width: 22px; height: 22px; border: 1px solid #2980b9; background: #fff; color: #2980b9; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; padding: 0;">i</button>
                </div>
                <div id="thesis-info" class="custom-panel watermark-info" style="display: none; position: absolute; bottom: 40px; font-size: 10px; color: #333; line-height: 1.5;">
                    <b>แผนที่นี้เป็นส่วนหนึ่งของรายงานการศึกษา เรื่อง การวิเคราะห์แนวโน้มการทรุดตัวของแผ่นดินในกรุงเทพมหานครด้วยวิธี InSAR ร่วมกับข้อมูลการใช้น้ำบาดาล</b><br>
                    ซึ่งเป็นปริญญานิพนธ์ส่วนหนึ่งของการศึกษาตามหลักสูตรปริญญาวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมโยธา คณะวิศวกรรมศาสตร์ มหาวิทยาลัยเทคโนโลยีพระจอมเกล้าธนบุรี ปีการศึกษา 2568<br><br>
                    <b>ผู้เขียน:</b> นางสาวกมลวรรณ วงศ์อำมาตย์, นายพีรพงศ์ จอมจุมพลภา, นางสาวรัตติยา สุขปลั่ง<br>
                    <b>อาจารย์ที่ปรึกษา:</b> ผศ.ดร.ชาญชัย เพชรพงศ์พันธุ์
                </div>
            </div>
            """
            m.get_root().html.add_child(folium.Element(academic_watermark))

            # --- 6. Technical Disclaimer (ขวาล่าง - แยกกล่องคอม/ปุ่มมือถือ) ---
            pub_date = datetime.now().strftime("%d %B %Y")
            tech_disclaimer = f"""
            <div class="disclaimer-wrapper">
                <div class="custom-panel disclaimer-desktop">
                    <b>System Information & Disclaimer:</b><br>
                    • Data Frame: Oct 2014 - Dec 2024<br>
                    • Publish Date: {pub_date}<br>
                    • Warning: ห้ามนำไปใช้ออกแบบอาคารรายหลังโดยไม่มีการเจาะสำรวจดินตามหลักวิศวกรรม
                </div>
                
                <div class="disclaimer-mobile">
                    <div style="background: rgba(255,255,255,0.96); padding: 8px 15px; border-radius: 20px; border: 1px solid #e74c3c; display: flex; align-items: center; gap: 10px; box-shadow: 2px 2px 5px rgba(0,0,0,0.1);">
                        <b style="color:#e74c3c; font-size:12px; margin:0;">Disclaimer</b>
                        <button onclick="var el = document.getElementById('disc-info'); el.style.display = (el.style.display === 'none') ? 'block' : 'none';" 
                                style="border-radius: 50%; width: 22px; height: 22px; border: 1px solid #e74c3c; background: #fff; color: #e74c3c; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; padding: 0;">!</button>
                    </div>
                    <div id="disc-info" class="custom-panel" style="display: none; position: absolute; bottom: 40px; right: 0; width: 250px; font-size: 10px; color: #555; line-height: 1.5;">
                        <b>System Information & Disclaimer:</b><br>
                        • Data Frame: Oct 2014 - Dec 2024<br>
                        • Publish Date: {pub_date}<br>
                        • Warning: ห้ามใช้ออกแบบโครงสร้างโดยไม่มีการเจาะสำรวจดิน
                    </div>
                </div>
            </div>
            """
            m.get_root().html.add_child(folium.Element(tech_disclaimer))

            # --- 7. HeatMap Layer ---
            HeatMap([[r['Lat'], r['Lon'], abs(r[target_col])] for _, r in df_merged.iterrows()], radius=20, blur=15, min_opacity=0.3).add_to(m)

            # --- 8. Markers & Popups ---
            shap_sub_cols = [c for c in df_merged.columns if c.startswith('SHAP_') and c.endswith('_%_RF') and 'Impact' not in c]
            base_feats = [c.replace('SHAP_', '').replace('_%_RF', '') for c in shap_sub_cols]

            for _, row in df_merged.iterrows():
                dist = DISTRICT_CODES.get(str(row['Station_ID'])[:2], "Unknown")
                actual_val = row[target_col]
                abs_val = abs(actual_val)
                clay = row.get(clay_col, 'N/A')
                
                if abs_val > 100: status_text_color, marker_color, status_label = '#c0392b', '#e74c3c', "เตือนภัยวิกฤต (Warning)"
                elif abs_val > 50: status_text_color, marker_color, status_label = '#d35400', '#f39c12', "เฝ้าระวัง (Watch)"
                else: status_text_color, marker_color, status_label = '#27ae60', '#2ecc71', "ปกติ (Stable)"

                rf_gw, xg_gw = row.get('SHAP_GW_Impact_%_RF', 0), row.get('SHAP_GW_Impact_%_XG', 0)
                err_rf, err_xg = row.get('Error_RF', np.nan), row.get('Error_XG', np.nan)
                
                rf_tag = "<br><span style='background-color:#ffeaa7; color:#d35400; padding:2px 4px; border-radius:3px; font-size:9px;'>🚨 Worst Anomaly</span>" if err_rf > 35 else "<br><span style='background-color:#d4efdf; color:#1e8449; padding:2px 4px; border-radius:3px; font-size:9px;'>🌟 Best Fit</span>" if err_rf < 5 else ""
                xg_tag = "<br><span style='background-color:#ffeaa7; color:#d35400; padding:2px 4px; border-radius:3px; font-size:9px;'>🚨 Worst Anomaly</span>" if err_xg > 35 else "<br><span style='background-color:#d4efdf; color:#1e8449; padding:2px 4px; border-radius:3px; font-size:9px;'>🌟 Best Fit</span>" if err_xg < 5 else ""

                table_rows = "".join([f"<tr style='border-bottom:1px solid #ecf0f1;'><td>{f}</td><td style='text-align:right;'>{row.get(f'SHAP_{f}_%_RF',0):.1f}%</td><td style='text-align:right;'>{row.get(f'SHAP_{f}_%_XG',0):.1f}%</td></tr>" for f in base_feats if row.get(f'SHAP_{f}_%_RF',0)>1 or row.get(f'SHAP_{f}_%_XG',0)>1])

                popup_html = f"""
                <div class='popup-container'>
                    <div style='background:#f4f7f6; padding:10px; border-radius:8px; border-left:5px solid {status_text_color}; margin-bottom:10px;'>
                        <b style='font-size:14px;'>Station: {row['Join_ID']} ({row['Well_ID']})</b><br><small>District: {dist} | Lat: {row['Lat']:.4f}, Lon: {row['Lon']:.4f}</small>
                    </div>
                    <div class='flex-row'>
                        <div class='flex-item' style='background:#fdfefe; padding:8px; border-radius:5px; text-align:center; border:1px solid {status_text_color}; box-shadow: 1px 1px 3px rgba(0,0,0,0.05);'>
                            <span style='font-size:11px; color:#555;'>Actual Subsidence <br><b>({status_label})</b></span><br><b style='font-size:16px; color:{status_text_color};'>{actual_val:.2f} mm</b>
                        </div>
                        <div class='flex-item' style='background:#eaf2f8; padding:8px; border-radius:5px; text-align:center; border:1px solid #5dade2; box-shadow: 1px 1px 3px rgba(0,0,0,0.05);'>
                            <span style='font-size:11px; color:#2980b9;'>Physical Data <br><b>Clay Thickness</b></span><br><b style='font-size:16px; color:#154360;'>{clay} m</b>
                        </div>
                    </div>
                    <div style='font-size:12px; font-weight:bold; color:#2c3e50; margin-bottom:5px; text-align:center;'>Model Performance & Explanation (SHAP)</div>
                    <div class='flex-row'>
                        <div class='flex-item' style='border:1px solid #ccc; border-radius:6px; padding:8px; text-align:center; background:#fafafa;'>
                            <small><b>RF</b> (R²:0.44)</small>
                            <div style='position:relative; height:50px; width:50px; background:conic-gradient(#3498db {rf_gw}%, #e67e22 {rf_gw}% 100%); border-radius:50%; margin:8px auto; display:flex; align-items:center; justify-content:center;'><div style='width:25px; height:25px; background-color:#fafafa; border-radius:50%;'></div></div>
                            <div style='font-size:10px;'><b>GW: {rf_gw:.1f}%</b><br>MAE: {err_rf:.1f} mm {rf_tag}</div>
                        </div>
                        <div class='flex-item' style='border:1px solid #ccc; border-radius:6px; padding:8px; text-align:center; background:#fafafa;'>
                            <small><b>XG</b> (R²:0.35)</small>
                            <div style='position:relative; height:50px; width:50px; background:conic-gradient(#3498db {xg_gw}%, #e67e22 {xg_gw}% 100%); border-radius:50%; margin:8px auto; display:flex; align-items:center; justify-content:center;'><div style='width:25px; height:25px; background-color:#fafafa; border-radius:50%;'></div></div>
                            <div style='font-size:10px;'><b>GW: {xg_gw:.1f}%</b><br>MAE: {err_xg:.1f} mm {xg_tag}</div>
                        </div>
                    </div>
                    <details style='border:1px solid #ddd; border-radius:6px; padding:8px; background:#fff;'>
                        <summary style='font-size:12px; cursor:pointer; color:#2c3e50; font-weight:bold;'>🔍 Sub-factors</summary>
                        <table style='width:100%; font-size:10px; margin-top:8px; border-collapse:collapse;'><tr style='background:#ecf0f1; font-weight:bold;'><td style='padding:4px;'>Factor</td><td style='text-align:right;'>RF</td><td style='text-align:right;'>XG</td></tr>{table_rows}</table>
                    </details>
                </div>
                """
                
                folium.CircleMarker(location=[row['Lat'], row['Lon']], radius=7, color='black', weight=1, fill=True, fill_color=marker_color, fill_opacity=0.9, popup=folium.Popup(popup_html, max_width='100%'), tooltip=folium.Tooltip(f"Station: {row['Join_ID']}", permanent=True, direction="top", className="station-label")).add_to(m)

            Fullscreen().add_to(m)
            m.save("Bangkok_Final_Thesis_Map.html")
            messagebox.showinfo("Success", "เรียบร้อยครับ! กล่อง Disclaimer บนคอมพิวเตอร์กลับมาแล้ว พร้อมทฤษฎีอธิบายฉบับสมบูรณ์")
            
        except Exception as e:
            import traceback
            messagebox.showerror("Runtime Error", f"Error: {str(e)}\n\n{traceback.format_exc()}")

if __name__ == "__main__":
    root = tk.Tk(); app = ProfessionalComparativeMap(root); root.mainloop()